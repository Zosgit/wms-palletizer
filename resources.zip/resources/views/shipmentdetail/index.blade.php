@extends('layouts.app')
@section('content')

<div class="container">
    <div class="card">
      <div class="card-header d-flex align-items-center"><div>Dostawa nr: <strong>{{ $shipment->ship_nr}}</strong></div><a class="btn btn-sm btn-secondary ms-auto me-1 d-print-none" href="#" onclick="javascript:window.print();">
          <svg class="icon">
            <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-print"></use>
          </svg> Print</a><a class="btn btn-sm btn-info me-1 d-print-none" href="#">
          <svg class="icon">
            <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-save"></use>
          </svg> Save</a></div>
      <div class="card-body">
        <div class="row mb-4">
          <!-- /.col-->
          <div class="col-sm-4">
            <h6 class="mb-3">Szczegóły:</h6>
            <div>Dok: dostawy: <strong>{{ $shipment->external_nr}}</strong></div>
            <div>Data przyjęcia: <strong>{{ $shipment->created_at}}</strong></div>
            <div>Status: <strong>{{ $shipment->status->code}}</strong></div>
            <div>Uwagi: {{ $shipment->remarks}}</div>
          </div>
          <div class="col-sm-4">
            <h6 class="mb-3">Dostarczył:</h6>
            <div><strong>{{ $shipment->firm->code}}</strong></div>
            <div>{{ $shipment->firm->longdesc}}</div>
            <div>{{ $shipment->firm->postcode.' - '.$shipment->firm->city}}</div>
          </div>
          <!-- /.col-->
          <div class="col-sm-4">
            <h6 class="mb-3">Właściciel:</h6>
            <div><strong>{{ $shipment->owner->code}}</strong></div>
            <div>{{ $shipment->owner->longdesc}}</div>
            <div>{{ $shipment->owner->postcode.' - '.$shipment->owner->city}}</div>
          </div>
          <!-- /.col-->
        </div>
        <!-- /.row-->

        <a href="{{ route('shipmentdetail.create',['shipment' => $shipment]) }}"
        class="btn btn-primary float-start px-4 btn-sm">Dodaj pozycję</a>
        <div class="table-responsive-sm">
          <table class="table table-striped">
            <thead>
              <tr>
                <th>Indeks</th>
                <th>Nr seryjny</th>
                <th>Termin</th>
                <th>Magazyn</th>
                <th>Kategoria</th>
                <th class="center">ilość</th>
                <th class="center">Operacje</th>
              </tr>
            </thead>
            <tbody>
                @foreach($shipmentdetails as $shipmentdetail)
                    <tr>
                        <td>{{ $shipmentdetail->prod_code }}</td>
                        <td class="center">{{ $shipmentdetail->serial_nr }}</td>
                        <td class="center">{{ $shipmentdetail->expiration_at }}</td>
                        <td class="center">{{ $shipmentdetail->logical_area->code }}</td>
                        <td class="center">{{ $shipmentdetail->product->producttype->code }}</td>
                        <td class="right">{{ $shipmentdetail->quantity }}</td>
                        <td>dd
                        </td>
                    </tr>
                @endforeach
                </tbody>

          </table>
        </div>
      </div>
    </div>
  </div>
  @endsection
