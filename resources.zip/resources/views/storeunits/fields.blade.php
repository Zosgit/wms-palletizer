<form action="{{ route('storeunits.store') }}" class="forms-sample" method="POST">
    @csrf
{{--szablon StoreUnitTypes--}}
<div class="card-body"><canvas id="myBarChart" width="100%" height="10"></canvas>



    <div class="col-md-6 p-3">
        <button type="submit" class="btn btn-primary mr-4">Potwierdź</button>
        <a href="{{ route('storeunittypes.index') }}"
                    class="btn btn-light">Anuluj</a>
    </div>
</div>
</form>
