@extends('layouts.app')

@section('content')

    <div class="card mb-4">
        <div class="card-header">
            Lista opakowań
                <a href="{{ route('storeunits.create') }}"
                    class="btn btn-primary float-end px-4 ">Dodaj</a>
        </div>

        <div class="card-body">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">Rodzaj opakowania</th>
                    <th scope="col">EAN opakowania</th>
                    <th scope="col">Lokalizacja</th>
                    <th scope="col">Multi</th>
                </tr>
                </thead>
                <tbody>
                @foreach($storeunits as $storeunit)
                    <tr>
                        <td>{{ $storeunit->storeunittype->code ?? '' }}</td>
                        <td>{{ $storeunit->ean }}</td>
                        <td>{{ $storeunit->id }}</td>
                        <td>{{ $storeunit->su_multi}}</td>
                    </tr>
                @endforeach
                </tbody>
            </table>

        </div>

        {{--
        <div class="card-footer">
            {{ $users->links() }}
        </div>
        --}}
    </div>

@endsection
